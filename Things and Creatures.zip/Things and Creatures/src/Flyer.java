public interface Flyer {
    void fly();
}
