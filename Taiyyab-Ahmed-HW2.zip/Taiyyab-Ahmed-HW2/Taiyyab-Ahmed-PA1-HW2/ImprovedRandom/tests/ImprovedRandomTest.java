import org.junit.Test;

import static org.junit.Assert.*;

public class ImprovedRandomTest {
    @Test
    public void Randomtest()
    {
        int max = 26;
        int min = 24;
     ImprovedRandom rand = new ImprovedRandom();
     int n = rand.randinrange(max, min);
     assertEquals(n, 25);
    }


}