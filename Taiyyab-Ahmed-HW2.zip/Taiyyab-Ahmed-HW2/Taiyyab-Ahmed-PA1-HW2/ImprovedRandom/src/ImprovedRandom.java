import java.util.Random;
public class ImprovedRandom extends Random{

    public ImprovedRandom()
    {
        super();
    }

    public ImprovedRandom(long seed)
    {
        super(seed);
    }

    public int randinrange(int max, int min)
    {
       ImprovedRandom rand = new ImprovedRandom();
       int n = min +  rand.nextInt(((max) - min) + 1);
        return n;
    }

}
