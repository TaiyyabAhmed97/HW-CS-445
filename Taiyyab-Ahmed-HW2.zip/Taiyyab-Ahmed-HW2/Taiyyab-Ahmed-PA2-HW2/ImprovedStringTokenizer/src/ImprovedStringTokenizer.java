import java.util.StringTokenizer;

public class ImprovedStringTokenizer extends StringTokenizer {
    public ImprovedStringTokenizer(String str)
    {
        super(str);
    }

    public String [] ParseStrings()
    {
        String [] strArray = new String[this.countTokens()];
        int i = 0;
        while(this.hasMoreTokens())
        {
            strArray[i] = this.nextToken();
            i++;
        }
        return strArray;
    }
}
