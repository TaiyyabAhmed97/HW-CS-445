import org.junit.Test;

import java.util.Arrays;

import static org.junit.Assert.*;

public class ImprovedStringTokenizerTest {

    @Test
    public void parsestringsTest()
    {
        String str2 = "This is a very easy test";
        ImprovedStringTokenizer str1 = new ImprovedStringTokenizer(str2);
        String str3 = String.join(" ", str1.ParseStrings());
        assertEquals(str3,"This is a very easy test");
    }

}