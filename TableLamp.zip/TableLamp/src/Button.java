package Button;

import Lightbulb.Lightbulb;
import Lightbulb.bulb;

public class Button{
    public boolean pressed;
    bulb mybulb = null;
    public Button()
    {
        mybulb = (bulb)(new Lightbulb());
        pressed = false;
    }



    public void switchOn()
    {

        mybulb.on();
        pressed = true;
        System.out.println("Button switched to ON");
    }

    public void switchOff()
    {
        mybulb.off();
        pressed = false;
        System.out.println("Button switched to OFF");
    }
}
