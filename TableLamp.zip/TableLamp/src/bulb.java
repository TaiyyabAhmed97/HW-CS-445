package Lightbulb;
public interface bulb {
    void on();
     void off();
}
