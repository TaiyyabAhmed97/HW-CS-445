import Lightbulb.Lightbulb;
import Button.Button;


public class tablelamp {

    public static void main(String [] args)
    {
        Button but1 = new Button();
        but1.switchOff();
        but1.switchOn();

    }
}
