package Lightbulb;
import Lightbulb.bulb;
public class Lightbulb implements bulb{
   public boolean on;

   public Lightbulb()
   {
       on = false;
   }

   @Override
   public void on()
   {
       on = true;
       System.out.println("Lightbulb on");
   }
    @Override
    public void off()
    {
        on = false;
        System.out.println("Lightbulb off");
    }

}
