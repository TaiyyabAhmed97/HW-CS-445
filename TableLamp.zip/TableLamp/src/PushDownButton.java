package Button;

import Lightbulb.Lightbulb;
import Lightbulb.bulb;

public class PushDownButton{
    public boolean pressed;
    bulb mybulb = null;
    public PushDownButton()
    {
        mybulb = (bulb)(new Lightbulb());
        pressed = false;
    }



    public void PushButton()
    {
        if(!pressed)
        {
            mybulb.on();
            System.out.println("Lightbulb is on now");
            pressed = true;
        }
        else
        {
            mybulb.off();
            System.out.println("Lightbulb is off now");
            pressed = false;
        }

    }
}

