import Button.PushDownButton;
import org.junit.Test;

import static org.junit.Assert.*;

public class PushDownButtonTest {
    @Test
    public void pushButtontrue() throws Exception {
        PushDownButton pdb = new PushDownButton();
        pdb.PushButton();
        assertEquals(pdb.pressed, true);
    }

    @Test
    public void pushButtonfalse() throws Exception {
        PushDownButton pdb = new PushDownButton();
        pdb.PushButton();
        pdb.PushButton();
        assertEquals(pdb.pressed, false);
    }

}