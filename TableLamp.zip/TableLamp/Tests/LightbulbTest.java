import Lightbulb.Lightbulb;
import Lightbulb.bulb;
import org.junit.Test;

import static org.junit.Assert.*;

public class LightbulbTest {
    @Test
    public void on() throws Exception {
        Lightbulb lb = new Lightbulb();
        lb.on();
        assertEquals(lb.on,true);

    }

    @Test
    public void off() throws Exception {
        Lightbulb lb = new Lightbulb();
        lb.off();
        assertEquals(lb.on,false);
    }

}