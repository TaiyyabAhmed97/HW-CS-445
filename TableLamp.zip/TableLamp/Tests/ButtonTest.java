import Button.Button;
import org.junit.Test;

import static org.junit.Assert.*;

public class ButtonTest {
    @Test
    public void switchOn() throws Exception {
        Button but = new Button();
        but.switchOn();
        assertEquals(but.pressed, true);
    }

    @Test
    public void switchOff() throws Exception {
        Button but = new Button();
        but.switchOff();
        assertEquals(but.pressed, false);
    }

}